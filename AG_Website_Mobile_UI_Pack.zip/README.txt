DG Mobile UI Pack
Structure: templates/, components/, icons/
All files are placeholders with brand-ready layout notes.